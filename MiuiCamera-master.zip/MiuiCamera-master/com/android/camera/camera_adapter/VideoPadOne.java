package com.android.camera.camera_adapter;

import com.android.camera.module.VideoModule;
import java.util.ArrayList;
import java.util.List;

public class VideoPadOne extends VideoModule {
    public List<String> getSupportedSettingKeys() {
        return new ArrayList();
    }
}
