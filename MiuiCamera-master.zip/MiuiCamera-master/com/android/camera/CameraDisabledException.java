package com.android.camera;

public class CameraDisabledException extends Exception {
    private static final long serialVersionUID = 1198924551039042639L;
}
