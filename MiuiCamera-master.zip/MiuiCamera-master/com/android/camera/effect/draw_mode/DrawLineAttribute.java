package com.android.camera.effect.draw_mode;

import com.android.gallery3d.ui.GLPaint;

public class DrawLineAttribute extends DrawAttribute {
    public GLPaint mGLPaint;
    public float mX1;
    public float mX2;
    public float mY1;
    public float mY2;
}
