package com.android.camera.effect.draw_mode;

import com.android.gallery3d.ui.GLPaint;

public class DrawRectAttribute extends DrawAttribute {
    public GLPaint mGLPaint;
    public float mHeight;
    public float mWidth;
    public float mX;
    public float mY;
}
