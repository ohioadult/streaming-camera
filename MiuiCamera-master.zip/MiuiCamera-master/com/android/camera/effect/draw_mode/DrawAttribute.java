package com.android.camera.effect.draw_mode;

public abstract class DrawAttribute {
    protected int mTarget = -1;

    public int getTarget() {
        return this.mTarget;
    }
}
