package com.android.camera.ui;

public interface MessageDispacher {
    boolean dispacherMessage(int i, int i2, int i3, Object obj, Object obj2);
}
