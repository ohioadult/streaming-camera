package com.android.camera.ui;

public interface MutexView {
    void hide();

    void show();
}
