package com.android.camera.ui;

public interface AnimateView {
    void hide(boolean z);
}
