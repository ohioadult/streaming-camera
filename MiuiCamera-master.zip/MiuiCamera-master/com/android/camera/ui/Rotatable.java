package com.android.camera.ui;

public interface Rotatable {
    void setOrientation(int i, boolean z);
}
