package com.android.camera;

public class CameraHardwareException extends Exception {
    private static final long serialVersionUID = -459192180104833293L;

    public CameraHardwareException(Throwable t) {
        super(t);
    }
}
