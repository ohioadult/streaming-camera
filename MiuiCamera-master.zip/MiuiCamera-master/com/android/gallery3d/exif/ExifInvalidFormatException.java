package com.android.gallery3d.exif;

public class ExifInvalidFormatException extends Exception {
    public ExifInvalidFormatException(String meg) {
        super(meg);
    }
}
