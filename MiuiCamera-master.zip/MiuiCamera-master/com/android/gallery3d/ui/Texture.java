package com.android.gallery3d.ui;

public interface Texture {
    boolean isOpaque();
}
