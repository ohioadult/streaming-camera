package miui.external;

public enum SdkConstants$SdkError {
    GENERIC,
    NO_SDK,
    LOW_SDK_VERSION
}
